"use client";

import { useEffect, useState } from "react";
import { db } from "@/firebase";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { useParams } from "next/navigation";

export default function RequestDetailPage() {
  const { requestId } = useParams();
  const [data, setData] = useState(null);

  useEffect(() => {
    async function load() {
      const ref = doc(db, "quote_requests", requestId);
      const snap = await getDoc(ref);

      if (snap.exists()) {
        setData({ id: snap.id, ...snap.data() });
      }
    }

    if (requestId) load();
  }, [requestId]);

  async function updateStatus(status) {
    const ref = doc(db, "quote_requests", requestId);

    await updateDoc(ref, {
      status
    });

    setData((prev) => ({ ...prev, status }));
  }

  if (!data) return <div className="p-6">Yükleniyor...</div>;

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-xl font-bold">Teklif Detayı</h1>

      <div className="bg-white p-4 rounded shadow">
        <div><b>Ad:</b> {data.customer?.name}</div>
        <div><b>Firma:</b> {data.customer?.company}</div>
        <div><b>Telefon:</b> {data.customer?.phone}</div>
        <div><b>Email:</b> {data.customer?.email}</div>
      </div>

      <div className="bg-white p-4 rounded shadow">
        <div className="mb-2 font-semibold">Durum</div>
        <div className="flex gap-2 flex-wrap">
          {["received","reviewing","preparing","offered","in_delivery","completed"].map(s => (
            <button
              key={s}
              onClick={() => updateStatus(s)}
              className="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300"
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white p-4 rounded shadow">
        <div className="font-semibold mb-2">Ürünler</div>

        {data.items?.length === 0 && <div>Ürün yok</div>}

        {data.items?.map((item, i) => (
          <div key={i} className="border-b py-2 text-sm">
            {item.requestedProduct?.name} - {item.qtyRequested}
          </div>
        ))}
      </div>

      <div className="bg-white p-4 rounded shadow">
        <div className="font-semibold">Toplam</div>
        <div>{data.pricing?.finalAmount || 0} KZT</div>
      </div>
    </div>
  );
}
