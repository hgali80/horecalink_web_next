"use client";

import { useEffect, useState } from "react";
import { db } from "@/firebase";
import { collection, getDocs, orderBy, query } from "firebase/firestore";
import { useRouter } from "next/navigation";

export default function QuotesPage() {
  const [threads, setThreads] = useState([]);
  const router = useRouter();

  useEffect(() => {
    async function load() {
      const q = query(
        collection(db, "quote_threads"),
        orderBy("lastRequestAt", "desc")
      );

      const snap = await getDocs(q);

      setThreads(
        snap.docs.map((d) => ({
          id: d.id,
          ...d.data()
        }))
      );
    }

    load();
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-6">Teklif Gelen Kutusu</h1>

      <div className="space-y-4">
        {threads.map((t) => (
          <div
            key={t.id}
            onClick={() => router.push(`/satissitok/admin/quotes/${t.id}`)}
            className="p-4 bg-white rounded-lg shadow cursor-pointer hover:bg-gray-50"
          >
            <div className="flex justify-between">
              <div>
                <div className="font-semibold">
                  {t.customer?.name} / {t.customer?.company}
                </div>
                <div className="text-sm text-gray-500">
                  {t.customer?.phone} - {t.customer?.email}
                </div>
              </div>

              {t.stats?.unreadCount > 0 && (
                <div className="text-xs bg-red-500 text-white px-2 py-1 rounded">
                  {t.stats.unreadCount} yeni
                </div>
              )}
            </div>

            <div className="mt-2 text-sm text-gray-600">
              Toplam Teklif: {t.stats?.totalRequests}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
